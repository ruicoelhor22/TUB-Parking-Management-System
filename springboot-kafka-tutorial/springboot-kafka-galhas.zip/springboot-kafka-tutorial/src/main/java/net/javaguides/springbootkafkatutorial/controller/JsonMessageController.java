package net.javaguides.springbootkafkatutorial.controller;

import net.javaguides.springbootkafkatutorial.payload.Senhas;
import net.javaguides.springbootkafkatutorial.kafka.JsonKafkaProducerSenhas;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestBody;


@RestController
@RequestMapping("/api/v1/kafka")


public class JsonMessageController {

    private Senhas senhas = new Senhas(); //Trocar para uma lista de senhas

    private JsonKafkaProducerSenhas kafkaProducer;

    public JsonMessageController(JsonKafkaProducerSenhas kafkaProducer) {
        this.kafkaProducer = kafkaProducer;
    }

    @PostMapping("/publish")
    public ResponseEntity<String> publish(@RequestBody Senhas user){
        kafkaProducer.sendMessage(user);
        senhas = user;
        return ResponseEntity.ok("Json message sent to kafka topic AAAA");
    }

    @GetMapping("/getSenhas")
    public Senhas getSenhas(){
        return senhas;
    }


}