package net.javaguides.springbootkafkatutorial.kafka;

import net.javaguides.springbootkafkatutorial.payload.Senhas;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

// fazer a soma das senhas
@Service
public class JsonKafkaConsumerSenhas {
    private static final Logger LOGGER = LoggerFactory.getLogger(JsonKafkaConsumerSenhas.class);

    @KafkaListener(topics = "javaguides_json", groupId = "${spring.kafka.consumer.group-id}")
    public void consume(Senhas senhas){
        LOGGER.info(String.format("Json message recieved -> %s", senhas.toString()));
    }
}

